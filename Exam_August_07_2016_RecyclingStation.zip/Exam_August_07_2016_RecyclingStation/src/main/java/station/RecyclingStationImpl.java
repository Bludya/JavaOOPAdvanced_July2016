package station;

import contracts.ManagingRequirements;
import contracts.RecyclingStation;
import framework.wasteDisposal.contracts.ProcessingData;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */


public class RecyclingStationImpl implements RecyclingStation {
    private double energyBalance;
    private double capitalBalance;
    private ManagingRequirements managingRequirements;

    //this one just opened so it starts with zero energy and zero capital - GL :D
    //also starts with managing requirements set to 0 as per problem description
    public RecyclingStationImpl() {
        this(new ManagingRequirementsImpl(0, 0, ""), 0, 0);
    }

    //so it can be used for different start
    public RecyclingStationImpl(
            ManagingRequirements managingRequirements,
            double energyBalance,
            double capitalBalance){
        this.setManagingRequirements(managingRequirements);
        this.setEnergyBalance(energyBalance);
        this.setCapitalBalance(capitalBalance);
    }

    private void setEnergyBalance(double energyBalance) {
        this.energyBalance = energyBalance;
    }

    private void setCapitalBalance(double capitalBalance) {
        this.capitalBalance = capitalBalance;
    }

    public double getEnergy() {
        return this.energyBalance;
    }

    public double getCapital() {
        return this.capitalBalance;
    }

    @Override
    public boolean isProcessingInpossible(ProcessingData processingData, String typeOfGarbage) {
        return (this.managingRequirements.getCapitalRequirement() > this.capitalBalance ||
                    this.managingRequirements.getEnergyRequirement() > this.energyBalance) &&
                        typeOfGarbage.equals(this.managingRequirements.getWasteType());
    }

    @Override
    public void setManagingRequirements(ManagingRequirements managingRequirements) {
        this.managingRequirements = managingRequirements;
    }

    @Override
    public void processData(ProcessingData processingData) {
        this.setEnergyBalance(this.energyBalance + processingData.getEnergyBalance());
        this.setCapitalBalance(this.capitalBalance + processingData.getCapitalBalance());
    }

    @Override
    public String toString(){
        return String.format("Energy: %.2f Capital: %.2f", this.energyBalance, this.capitalBalance);
    }
}
