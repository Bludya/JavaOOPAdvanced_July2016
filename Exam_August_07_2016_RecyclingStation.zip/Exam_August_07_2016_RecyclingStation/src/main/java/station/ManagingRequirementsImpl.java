package station;

import contracts.ManagingRequirements;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class ManagingRequirementsImpl  implements ManagingRequirements{
    private double energyRequired;
    private double capitalRequired;
    private String wasteType;

    public ManagingRequirementsImpl(
            double energyRequired,
            double capitalRequired,
            String wasteType
    ) {
        this.setEnergyRequired(energyRequired);
        this.setCapitalRequired(capitalRequired);
        this.setWasteType(wasteType);
    }

    private void setEnergyRequired(double energyRequired) {
        this.energyRequired = energyRequired;
    }

    private void setCapitalRequired(double capitalRequired) {
        this.capitalRequired = capitalRequired;
    }

    private void setWasteType(String wasteType) {
        this.wasteType = wasteType;
    }

    @Override
    public double getEnergyRequirement() {
        return this.energyRequired;
    }

    @Override
    public double getCapitalRequirement() {
        return capitalRequired;
    }

    @Override
    public String getWasteType() {
        return this.wasteType;
    }

}
