
import annotations.Inject;
import commands.Command;
import contracts.*;
import contracts.Runnable;
import framework.wasteDisposal.contracts.GarbageProcessor;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class Core implements Runnable{
    private final String COMMANDS_PACKAGE = "commands.";

    private InputReader reader;
    private OutputWriter writer;
    private CommandInterpreter interpreter;

    public Core(
            InputReader reader,
            OutputWriter writer,
            CommandInterpreter interpreter) {
        this.reader = reader;
        this.writer = writer;
        this.interpreter = interpreter;
    }

    public void run() throws IOException, ReflectiveOperationException {
        while (true){
            String[] input = reader.readLine().split("\\s+");

            if(input[0].equals("TimeToRecycle")){
                break;
            }

            Executable command = this.interpreter.interpret(input);
            writer.writeLine(command.execute());
        }
    }
}
