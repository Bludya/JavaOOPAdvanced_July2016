package disposeStrategies;

import framework.wasteDisposal.contracts.GarbageDisposalStrategy;
import framework.wasteDisposal.contracts.ProcessingData;
import framework.wasteDisposal.contracts.Waste;
import processingData.ProcessingDataImpl;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public abstract class DisposeStrategy implements GarbageDisposalStrategy {
    protected double energyBalancePercentageMultiplier;
    protected double capitalBalancePercentageMultiplier;

    protected DisposeStrategy(
            double energyBalancePercentageMultiplier,
            double capitalBalancePercentageMultiplier) {
        this.setEnergyBalancePercentageMultiplier(energyBalancePercentageMultiplier);
        this.setCapitalBalancePercentageMultiplier(capitalBalancePercentageMultiplier);
    }

    private void setEnergyBalancePercentageMultiplier(double energyBalancePercentageMultiplier) {
        this.energyBalancePercentageMultiplier = energyBalancePercentageMultiplier;
    }

    private void setCapitalBalancePercentageMultiplier(double capitalBalancePercentageMultiplier) {
        this.capitalBalancePercentageMultiplier = capitalBalancePercentageMultiplier;
    }

    protected double getTotalVolume(Waste waste){
        return waste.getWeight() * waste.getVolumePerKg();
    }

    public ProcessingData processGarbage(Waste garbage) {
        double totalVolume = this.getTotalVolume(garbage);

        double energyBalance = this.energyBalancePercentageMultiplier * totalVolume;
        double capitalBalance = this.capitalBalancePercentageMultiplier * totalVolume;

        return new ProcessingDataImpl(energyBalance, capitalBalance);
    }

}
