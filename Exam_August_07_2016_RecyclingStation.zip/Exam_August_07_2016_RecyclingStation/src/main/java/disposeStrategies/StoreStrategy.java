package disposeStrategies;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class StoreStrategy extends DisposeStrategy {

    //13% of the total garbage volume ised as energy
    private static final double ENERGY_PERCENTAGE_MULTIPLIER = -0.13;

    //65% of the total garbage volume used as capital
    private static final double CAPITAL_PERCENTAGE_MULTIPLIER = -0.65;

    public StoreStrategy() {
        super(
                ENERGY_PERCENTAGE_MULTIPLIER,
                CAPITAL_PERCENTAGE_MULTIPLIER);
    }
}
