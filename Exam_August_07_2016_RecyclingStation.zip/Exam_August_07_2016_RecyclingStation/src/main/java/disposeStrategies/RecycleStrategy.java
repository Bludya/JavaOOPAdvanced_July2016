package disposeStrategies;

import framework.wasteDisposal.contracts.ProcessingData;
import framework.wasteDisposal.contracts.Waste;
import processingData.ProcessingDataImpl;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class RecycleStrategy extends DisposeStrategy{
    //50% the total garbage volume used as energy
    private static final double ENERGY_PERCENTAGE_MULTIPLIER = -0.5;

    //400 of the total garbage volume as capital
    private static final double CAPITAL_PERCENTAGE_MULTIPLIER = 400;

    public RecycleStrategy() {
        super(
                ENERGY_PERCENTAGE_MULTIPLIER,
                CAPITAL_PERCENTAGE_MULTIPLIER);
    }

    //overriding since the calcultion is a bit different.
    // Can be made more general with passing the variables needed for calc in constructor.
    @Override
    public ProcessingData processGarbage(Waste garbage) {
        double totalVolume = this.getTotalVolume(garbage);

        double energyBalance = super.energyBalancePercentageMultiplier * totalVolume;
        double capitalBalance = this.capitalBalancePercentageMultiplier * garbage.getWeight();

        return new ProcessingDataImpl(energyBalance, capitalBalance);
    }
}
