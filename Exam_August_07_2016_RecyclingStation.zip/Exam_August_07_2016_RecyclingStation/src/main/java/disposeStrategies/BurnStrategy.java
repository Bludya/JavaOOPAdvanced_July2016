package disposeStrategies;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class BurnStrategy extends DisposeStrategy{

    //100% - 20% = 80% of the total garbage volume as energy
    private static final double ENERGY_PERCENTAGE_MULTIPLIER = 0.8;

    //0% of total garbage volume as capital
    private static final double CAPITAL_PERCENTAGE_MULTIPLIER = 0;

    public BurnStrategy() {
        super(
                ENERGY_PERCENTAGE_MULTIPLIER,
                CAPITAL_PERCENTAGE_MULTIPLIER);
    }
}
