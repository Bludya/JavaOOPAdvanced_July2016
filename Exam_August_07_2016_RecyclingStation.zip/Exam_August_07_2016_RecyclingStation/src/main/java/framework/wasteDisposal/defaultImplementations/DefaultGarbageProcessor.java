package framework.wasteDisposal.defaultImplementations;

import framework.wasteDisposal.annotations.Disposable;
import framework.wasteDisposal.contracts.*;

import java.lang.annotation.Annotation;

public class DefaultGarbageProcessor implements GarbageProcessor {
    private StrategyHolder strategyHolder;

    public DefaultGarbageProcessor(StrategyHolder strategyHolder){
        this.setStrategyHolder(strategyHolder);
    }

    public DefaultGarbageProcessor(){
        this(new DefaultStrategyHolder());
    }

    private void setStrategyHolder(StrategyHolder strategyHolder) {
        this.strategyHolder = strategyHolder;
    }

    public StrategyHolder getStrategyHolder() {
        return this.strategyHolder;
    }

    public ProcessingData processWaste(Waste garbage) {
        Class type = garbage.getClass();
        Annotation[] garbageAnnotations = type.getDeclaredAnnotations();

        //changed so it fits the StrategyHolder requirements
        Annotation disposableAnnotation = null;
        for (Annotation annotation : garbageAnnotations){
            //was wrong - fixed
            if(annotation.annotationType().isAnnotationPresent(Disposable.class)){
                disposableAnnotation = annotation;
                break;
            }
        }

        GarbageDisposalStrategy currentStrategy;

        if (disposableAnnotation == null || !this.getStrategyHolder().getDisposalStrategies().containsKey(disposableAnnotation.annotationType()))
        {
            throw new IllegalArgumentException(
                    "The passed in garbage does not implement an annotation implementing the Disposable meta-annotation or is not supported by the StrategyHolder.");
        }

        currentStrategy = this.getStrategyHolder().getDisposalStrategies().get(disposableAnnotation.annotationType());
        return currentStrategy.processGarbage(garbage);
    }
}
