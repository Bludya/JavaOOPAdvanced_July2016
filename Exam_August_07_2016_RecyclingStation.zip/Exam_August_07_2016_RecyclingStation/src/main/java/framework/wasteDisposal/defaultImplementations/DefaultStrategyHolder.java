package framework.wasteDisposal.defaultImplementations;

import framework.wasteDisposal.annotations.Disposable;
import framework.wasteDisposal.contracts.GarbageDisposalStrategy;
import framework.wasteDisposal.contracts.StrategyHolder;

import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class DefaultStrategyHolder implements StrategyHolder {

    //changed to hold Class<? extends Annotation> as keys. Required as per Interface documentation
    private LinkedHashMap<Class,GarbageDisposalStrategy> strategies;

    public DefaultStrategyHolder(){
        this.strategies = new LinkedHashMap<>();
    }

    public Map<Class, GarbageDisposalStrategy> getDisposalStrategies() {
        return Collections.unmodifiableMap(this.strategies);
    }

    //Added conditions to check if @Disposable is set to the annotation and if the strategy is already present.
    public boolean addStrategy(Class annotationClass, GarbageDisposalStrategy strategy) {

        if(annotationClass.getClass().getSuperclass() == Annotation.class){
            return false;
        }

        if(this.strategies.containsKey(annotationClass)){
            return false;
        }

        if(!annotationClass.isAnnotationPresent(Disposable.class)){
            return false;
        }

        this.strategies.put(annotationClass,strategy);
        return true;
    }

    //Added conditions to check if @Disposable is set to the annotation and if the strategy is not present.
    public boolean removeStrategy(Class annotationClass) {

        if(annotationClass.getClass().getSuperclass() == Annotation.class){
            return false;
        }

        if(!this.strategies.containsKey(annotationClass)){
            return false;
        }

        if(!annotationClass.isAnnotationPresent(Disposable.class)){
            return false;
        }

        this.strategies.remove(annotationClass);
        return true;
    }
}
