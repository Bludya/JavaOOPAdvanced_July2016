import commands.CommandInterpreterImpl;
import contracts.*;
import contracts.Runnable;
import framework.wasteDisposal.contracts.GarbageProcessor;
import framework.wasteDisposal.contracts.StrategyHolder;
import framework.wasteDisposal.defaultImplementations.DefaultGarbageProcessor;
import framework.wasteDisposal.defaultImplementations.DefaultStrategyHolder;
import io.ConcoleWriter;
import io.ConsoleReader;
import station.RecyclingStationImpl;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        StrategyHolder strategyHolder = new DefaultStrategyHolder();
        GarbageProcessor garbageProcessor = new DefaultGarbageProcessor(strategyHolder);
        RecyclingStation recyclingStation = new RecyclingStationImpl();


        InputReader inputReader = new ConsoleReader();
        OutputWriter outputWriter = new ConcoleWriter();

        CommandInterpreter interpreter = new CommandInterpreterImpl(recyclingStation, garbageProcessor);

        Runnable core = new Core(inputReader, outputWriter, interpreter);
        try {
            core.run();
        }catch (IOException ioe){
            outputWriter.writeLine("Can't access reader data.");
        } catch (ReflectiveOperationException e) {
            outputWriter.writeLine(e.getMessage());
        }
    }
}
