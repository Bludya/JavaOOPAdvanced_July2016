package contracts;

import framework.wasteDisposal.contracts.ProcessingData;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public interface RecyclingStation {

    double getEnergy();

    double getCapital();

    boolean isProcessingInpossible(ProcessingData processingData, String typeOfGarbage);

    void setManagingRequirements(ManagingRequirements managingRequirements);

    void processData(ProcessingData processingData);
}
