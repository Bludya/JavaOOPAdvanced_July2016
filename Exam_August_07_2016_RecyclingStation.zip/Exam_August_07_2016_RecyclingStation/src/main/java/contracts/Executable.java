package contracts;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public interface Executable {
    String execute() throws ReflectiveOperationException;
}
