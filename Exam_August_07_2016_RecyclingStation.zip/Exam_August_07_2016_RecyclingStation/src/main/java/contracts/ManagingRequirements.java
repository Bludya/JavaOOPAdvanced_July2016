package contracts;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public interface ManagingRequirements {

    double getEnergyRequirement();

    double getCapitalRequirement();

    String getWasteType();
}
