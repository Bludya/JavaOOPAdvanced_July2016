package contracts;

import java.io.IOException;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public interface Runnable {
    void run() throws IOException, ReflectiveOperationException;
}
