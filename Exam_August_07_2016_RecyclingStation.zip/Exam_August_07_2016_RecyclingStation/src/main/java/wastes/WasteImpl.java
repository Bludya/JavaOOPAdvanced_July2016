package wastes;

import framework.wasteDisposal.contracts.Waste;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public abstract class WasteImpl implements Waste{
    private String name;
    private double weight;
    private double volumePerKg;

    protected WasteImpl(
            String name,
            double weight,
            double volumePerKg) {
        this.setName(name);
        this.setWeight(weight);
        this.setVolumePerKg(volumePerKg);
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setWeight(double weight) {
        this.weight = weight;
    }

    private void setVolumePerKg(double volumePerKg) {
        this.volumePerKg = volumePerKg;
    }

    public String getName(){
        return this.name;
    }

    public double getWeight() {
        return this.weight;
    }

    public double getVolumePerKg() {
        return this.volumePerKg;
    }
}
