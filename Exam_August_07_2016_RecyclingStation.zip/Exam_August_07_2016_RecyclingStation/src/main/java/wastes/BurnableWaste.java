package wastes;

import annotations.Burn;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
@Burn
public class BurnableWaste extends WasteImpl{

    public BurnableWaste(
            String name,
            double weight,
            double volumePerKg) {
        super(
                name,
                weight,
                volumePerKg);
    }
}
