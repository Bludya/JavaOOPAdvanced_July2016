package wastes;

import annotations.Recycle;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */

@Recycle
public class RecyclableWaste extends WasteImpl{

    public RecyclableWaste(
            String name,
            double weight,
            double volumePerKg) {
        super(
                name,
                weight,
                volumePerKg);
    }
}
