package wastes;

import annotations.Store;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
@Store
public class StorableWaste extends WasteImpl{

    public StorableWaste(
            String name,
            double weight,
            double volumePerKg) {
        super(
                name,
                weight,
                volumePerKg);
    }
}
