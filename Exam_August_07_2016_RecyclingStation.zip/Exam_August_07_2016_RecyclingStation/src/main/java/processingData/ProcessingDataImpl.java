package processingData;

import framework.wasteDisposal.contracts.ProcessingData;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class ProcessingDataImpl implements ProcessingData {
    private double energyBalance;
    private double capitalBalance;

    public ProcessingDataImpl(
            double energyBalance,
            double capitalBalance) {
        this.setEnergyBalance(energyBalance);
        this.setCapitalBalance(capitalBalance);
    }

    private void setEnergyBalance(double energyBalance) {
        this.energyBalance = energyBalance;
    }

    private void setCapitalBalance(double capitalBalance) {
        this.capitalBalance = capitalBalance;
    }

    public double getEnergyBalance() {
        return this.energyBalance;
    }

    public double getCapitalBalance() {
        return this.capitalBalance;
    }
}
