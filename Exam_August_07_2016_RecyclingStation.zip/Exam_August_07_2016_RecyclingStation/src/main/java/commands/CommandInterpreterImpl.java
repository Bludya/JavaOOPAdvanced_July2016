package commands;

import annotations.Inject;
import contracts.*;
import framework.wasteDisposal.contracts.GarbageProcessor;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class CommandInterpreterImpl implements CommandInterpreter {
    private final String COMMANDS_PACKAGE = "commands.";

    private RecyclingStation recyclingStation;
    private GarbageProcessor garbageProcessor;

    public CommandInterpreterImpl(RecyclingStation recyclingStation,
                                  GarbageProcessor garbageProcessor) {
        this.recyclingStation = recyclingStation;
        this.garbageProcessor = garbageProcessor;
    }

    @Override
    public Executable interpret(String[] input) throws ReflectiveOperationException {
        String commandName = input[0];

        String[] data = null;
        if(input.length > 1){
            data = input[1].split("\\|");
        }
        Executable command = this.makeCommand(commandName, data);

        return command;
    }

    private Executable makeCommand(String commandName, String[] data) throws ReflectiveOperationException{
        Class commandType = Class.forName(COMMANDS_PACKAGE + commandName + "Command");
        Constructor commandCtor = commandType.getConstructor(String[].class);
        Executable command = (Executable) commandCtor.newInstance((Object) data);

        this.injectFields(command);

        return command;
    }

    //injection - looks for fields with @Inject in the command and sets them if they match any if this class fields
    private void injectFields(Executable command) throws IllegalAccessException {
        Field[] commandFields = command.getClass().getDeclaredFields();
        for (Field commandField : commandFields) {
            if(!commandField.isAnnotationPresent(Inject.class)){
                continue;
            }

            Field[] thisFields = this.getClass().getDeclaredFields();
            for (Field thisField : thisFields) {
                if(!thisField.getType().equals(commandField.getType())){
                    continue;
                }

                commandField.setAccessible(true);
                thisField.setAccessible(true);

                commandField.set(command, thisField.get(this));
            }
        }
    }
}
