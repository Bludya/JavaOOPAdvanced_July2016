package commands;

import annotations.Inject;
import contracts.ManagingRequirements;
import contracts.RecyclingStation;
import station.ManagingRequirementsImpl;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class ChangeManagementRequirementCommand extends Command {

    @Inject
    private RecyclingStation recyclingStation;

    public ChangeManagementRequirementCommand(String[] data) {
        super(data);
        this.recyclingStation = null;
    }

    @Override
    public String execute() throws ReflectiveOperationException {
        double energyBalance = Double.parseDouble(this.data[0]);
        double capitalBalance = Double.parseDouble(this.data[1]);
        String wasteType = data[2];

        ManagingRequirements managingRequirements = new ManagingRequirementsImpl(energyBalance, capitalBalance, wasteType);

        this.recyclingStation.setManagingRequirements(managingRequirements);
        return "Management requirement changed!";
    }
}
