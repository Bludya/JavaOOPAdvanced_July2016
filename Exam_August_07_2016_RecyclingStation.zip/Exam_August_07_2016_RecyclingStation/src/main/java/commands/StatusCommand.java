package commands;

import annotations.Inject;
import contracts.RecyclingStation;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class StatusCommand extends Command {

    @Inject
    private RecyclingStation recyclingStation;

    public StatusCommand(String[] data) {
        super(data);

        //will be injected
        this.recyclingStation = null;
    }

    public String execute() {
        return recyclingStation.toString();
    }
}
