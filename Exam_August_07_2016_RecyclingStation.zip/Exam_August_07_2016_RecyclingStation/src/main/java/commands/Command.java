package commands;

import contracts.Executable;
import framework.wasteDisposal.contracts.Waste;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public abstract class Command implements Executable{
    protected String[] data;

    protected Command(String[] data) {
        this.data = data;
    }


}
