package commands;

import annotations.Inject;
import contracts.RecyclingStation;
import framework.wasteDisposal.annotations.Disposable;
import framework.wasteDisposal.contracts.*;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class ProcessGarbageCommand extends Command {

    private final String PACKAGE_TO_WASTES = "wastes.";
    private final String PACKAGE_STRATEGIES = "disposeStrategies.";

    @Inject
    private RecyclingStation recyclingStation;
    @Inject
    private GarbageProcessor garbageProcessor;

    public ProcessGarbageCommand(String[] data) {
        super(data);

        //will be injected
        this.recyclingStation = null;
        this.garbageProcessor = null;
    }

    @Override
    public String execute() throws ReflectiveOperationException {

        Waste waste = this.getWaste();

        String wasteType = this.data[3];

        String typeOfGarbage = this.addStrategyForWaste(waste);

        ProcessingData processingData = garbageProcessor.processWaste(waste);

        if(recyclingStation.isProcessingInpossible(processingData, wasteType) ){
            return "Processing Denied!";
        }

        recyclingStation.processData(processingData);

        return String.format("%.2f kg of %s successfully processed!", waste.getWeight(), waste.getName());
    }

    //gets strategy with reflection
    private String addStrategyForWaste(Waste waste) throws ReflectiveOperationException {
        Annotation annotation = null;

        for(Annotation classAnnotation : waste.getClass().getDeclaredAnnotations()){
            Class<Annotation> classAnnotationType =(Class<Annotation>) classAnnotation.annotationType();

            if(classAnnotationType.isAnnotationPresent(Disposable.class)){
                annotation = classAnnotation;
            }

        }

        if(annotation == null){
            throw new ReflectiveOperationException("Annotation not found");
        }

        String typeOfGarbage = annotation.annotationType().getSimpleName();
        Class<GarbageDisposalStrategy> strategyClass =(Class<GarbageDisposalStrategy>) Class.forName(PACKAGE_STRATEGIES + typeOfGarbage + "Strategy");
        Constructor<GarbageDisposalStrategy> strategyCtor = strategyClass.getConstructor();

        GarbageDisposalStrategy strategy = strategyCtor.newInstance();

        this.garbageProcessor.getStrategyHolder().addStrategy(annotation.annotationType(), strategy);

        return typeOfGarbage;
    }

    private Waste getWaste() throws ReflectiveOperationException{
        String name = this.data[0];
        double weight = Double.parseDouble(this.data[1]);
        double volumePerKg = Double.parseDouble(this.data[2]);
        String type = data[3];

        Class<Waste> wasteClass = (Class<Waste>) Class.forName(PACKAGE_TO_WASTES + type + "Waste");
        Constructor<Waste> wasteConstructor = wasteClass.getConstructor(String.class, double.class, double.class);

        return wasteConstructor.newInstance(name, weight, volumePerKg);
    }
}
