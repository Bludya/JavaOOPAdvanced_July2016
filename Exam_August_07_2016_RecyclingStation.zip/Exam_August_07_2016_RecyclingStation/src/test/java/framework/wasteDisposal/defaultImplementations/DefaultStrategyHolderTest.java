package framework.wasteDisposal.defaultImplementations;

import annotations.Burn;
import annotations.Inject;
import annotations.Recycle;
import disposeStrategies.BurnStrategy;
import framework.wasteDisposal.contracts.GarbageDisposalStrategy;
import framework.wasteDisposal.contracts.StrategyHolder;
import framework.wasteDisposal.contracts.Waste;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import wastes.BurnableWaste;

import java.lang.annotation.Annotation;

import static org.junit.Assert.*;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class DefaultStrategyHolderTest {
    private StrategyHolder holder;
    private GarbageDisposalStrategy strategy = new BurnStrategy();

    @Before
    public void setUp() throws Exception {
        holder = new DefaultStrategyHolder();
    }

    @Test
    public void disposalStrategiesShouldNotBeNull(){
        //Arrange
        boolean expecter = false;
        //Act
        boolean actual = this.holder.getDisposalStrategies() == null;
        //Assert
        Assert.assertEquals(expecter, actual);
    }

    @Test
    public void disposalStrategiesHolderSizeShouldBeZero(){
        //Arrange
        int expected = 0;
        //Act
        int actual = this.holder.getDisposalStrategies().size();
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void addStrategyShouldWorkNormally(){
        holder.addStrategy(Burn.class, this.strategy);
        //Arrange
        int expected = 1;
        //Act
        int actual = this.holder.getDisposalStrategies().size();
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void addStrategyWithDisposableAnnotationTypeShouldReturnTrue(){

        //Arrange
        boolean expected = true;
        //Act
        boolean actual = holder.addStrategy(Burn.class, this.strategy);
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void addStrategyWithNonAnnotationTypeShouldReturnFalse(){

        //Arrange
        boolean expected = false;
        //Act
        boolean actual = holder.addStrategy(String.class, this.strategy);
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void addStrategyWithExistingEntryShouldReturnFalse(){
        holder.addStrategy(Burn.class, this.strategy);

        //Arrange
        boolean expected = false;
        //Act
        boolean actual = holder.addStrategy(Burn.class, this.strategy);
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void addStrategyWithNonExistingEntryShouldReturnTrue(){
        holder.addStrategy(Burn.class, this.strategy);

        //Arrange
        boolean expected = true;
        //Act
        boolean actual = holder.addStrategy(Recycle.class, this.strategy);
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void addStrategyWithAnnotationWithoutDisposableMetaShouldReturnFalse(){
        //Arrange
        boolean expected = false;
        //Act
        boolean actual = holder.addStrategy(Inject.class, this.strategy);
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void removeStrategyNonAnnotationClassShouldReturnFalse(){
        //Arrange
        boolean expected = false;
        //Act
        boolean actual = holder.removeStrategy(String.class);
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void removeStrategyAnnotationClassAndExistingElementShouldReturnTrue(){
        holder.addStrategy(Burn.class, this.strategy);
        //Arrange
        boolean expected = true;
        //Act
        boolean actual = holder.removeStrategy(Burn.class);
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void removeStrategyWithNoElementsShouldReturnFalse(){
        //Arrange
        boolean expected = false;
        //Act
        boolean actual = holder.removeStrategy(Burn.class);
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void removeStrategyWithNotExistingElementShouldReturnFalse(){
        this.holder.addStrategy(Burn.class, this.strategy);
        //Arrange
        boolean expected = false;
        //Act
        boolean actual = holder.removeStrategy(Recycle.class);
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void removeStrategyWithNotDisposableMetaAnnotationShouldReturnFalse(){
        this.holder.addStrategy(Burn.class, this.strategy);
        //Arrange
        boolean expected = false;
        //Act
        boolean actual = holder.removeStrategy(Inject.class);
        //Assert
        Assert.assertEquals(expected, actual);
    }

}