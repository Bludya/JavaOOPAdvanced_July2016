package framework.wasteDisposal.defaultImplementations;

import annotations.Burn;
import annotations.Recycle;
import disposeStrategies.BurnStrategy;
import disposeStrategies.DisposeStrategy;
import framework.wasteDisposal.contracts.GarbageDisposalStrategy;
import framework.wasteDisposal.contracts.GarbageProcessor;
import framework.wasteDisposal.contracts.ProcessingData;
import framework.wasteDisposal.contracts.StrategyHolder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import wastes.BurnableWaste;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created by bludya on 8/7/16.
 * All rights reserved!
 */
public class DefaultGarbageProcessorTest {
    GarbageProcessor mockedProcessor;
    StrategyHolder mockedHolder;

    @Before
    public void setUp(){
        mockedHolder = Mockito.mock(DefaultStrategyHolder.class);
        mockedProcessor = new DefaultGarbageProcessor(mockedHolder);
    }

    @Test
    public void getStrategyHolderShouldReturnMockedHolder(){
        //Arrange
        boolean expected = true;
        //Act
        boolean actual = this.mockedProcessor.getStrategyHolder() == this.mockedHolder;
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void getStrategyHolderOnDefaultInitializationShouldReturnDefaultStrategyHolder(){
        GarbageProcessor processor = new DefaultGarbageProcessor();

        //Arrange
        boolean expected = true;
        //Act
        boolean actual = processor.getStrategyHolder().getClass() == DefaultStrategyHolder.class;
        //Assert
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void processWasteWithExistingStrategyShouldWork(){
        //make map with specific Entry so it can be tested
        Map<Class, GarbageDisposalStrategy> mockmap = new HashMap<>();
        mockmap.put(Burn.class, new BurnStrategy());

        //make mockedHolder return the map with the existing entry
        //this method is used inside the processWaste method to get the strategy
        Mockito.when(this.mockedHolder.getDisposalStrategies()).thenReturn(mockmap);

        //get the strategy, then get its interface so it can be compared to ProcessingData interface
        Class[] interfaces = this.mockedProcessor
                .processWaste(
                        new BurnableWaste("MockitoGarbageFTW", 0, 0))
                .getClass()
                .getInterfaces();


        //Arrange
        boolean expected = true;
        //Act
        //iterate trough all interfaces and check if the expected is there
        boolean actual = false;
        for (Class anInterface : interfaces) {
            if(anInterface == ProcessingData.class){
                actual = true;
                break;
            }
        }
        //Assert
        Assert.assertEquals(expected, actual);

    }

    @Test(expected = IllegalArgumentException.class)
    public void checkMissingStrategyThrowsException(){
        //make map with specific Entry so it can be tested
        Map<Class, GarbageDisposalStrategy> mockmap = new HashMap<>();
        mockmap.put(Recycle.class, new BurnStrategy());

        //make mockedHolder return the map with the existing entry
        //this method is used inside the processWaste method to get the strategy
        Mockito.when(this.mockedHolder.getDisposalStrategies()).thenReturn(mockmap);

        //try to get the missing strategy and throw exception
        //should throw exception here
        Class[] interfaces = this.mockedProcessor
                .processWaste(
                        new BurnableWaste("MockitoGarbageFTW", 0, 0))
                .getClass()
                .getInterfaces();
    }

}