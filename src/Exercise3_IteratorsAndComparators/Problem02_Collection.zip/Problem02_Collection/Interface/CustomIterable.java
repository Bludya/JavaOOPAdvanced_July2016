package Exercise3_IteratorsAndComparators.Problem02_Collection.Interface;

/**
 * Created by bludya on 7/26/16.
 * All rights reserved!
 */
public interface CustomIterable {
    boolean move();

    boolean hasNext();

    String print();
}
